﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Tracing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace lab7_152120231058_152120221058_Group17
{
    public enum Theme
    {
        Man,
        Flower,
        Castle
    }
    public partial class HangmanGame: Form
    {
        string word = "";
        int point = 100;
        Theme usedTheme;
        Dictionary<string, string> selectedCategoryWords;
        Dictionary<Theme, Image[]> themes;
        Timer timer;
        int remainingTime;
        public HangmanGame(int timeFromSettings, string difficulty, string category, Theme theme)
        {
            InitializeComponent();
            if(string.IsNullOrEmpty(difficulty))
            {
                difficulty = "easy"; // Default difficulty
            }
            remainingTime = timeFromSettings > 0 ? timeFromSettings : 60; // 60 default
            /*if (string.IsNullOrEmpty(category))
            {
                category = "Movies"; // Default category
            }*/
            selectedCategoryWords = GetCategoryWords(category);
            word = GetRandomWord(difficulty);
            usedTheme = theme;
            lblCategory.Text = "Category: " + category;
            lblDifficulty.Text = "Difficulty: " + difficulty;
            LoadThemeImages();
        }

        private void HangmanGame_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        // Movies
        Dictionary<string, string> movieWords = new Dictionary<string, string>
            {
                { "up", "Animated film with balloons" },
                { "elf", "Christmas comedy movie" },
                { "saw", "Horror movie with traps" },
                { "cars", "Animated movie about racing" },
                { "fame", "Movie about performing arts" },
                { "her", "AI love story" },
                { "bolt", "Dog with superpowers" },
                { "hook", "Peter Pan themed movie" },

                { "avatar", "Blue aliens and Pandora" },
                { "rocky", "Famous boxing movie" },
                { "inception", "Dreams inside dreams" },
                { "gladiator", "Roman warrior's revenge" },
                { "goodfellas", "Gangster classic film" },
                { "scarface", "Say hello to my little friend" },
                { "titanic", "Ship disaster love story" },
                { "skyfall", "James Bond movie" },

                { "interstellar", "Space and time travel movie" },
                { "schindlerslist", "WWII Holocaust story" },
                { "thegodfather", "Mafia family saga" },
                { "fightclub", "Secret underground club" },
                { "pulpfiction", "Tarantino classic crime film" },
                { "shawshank", "Prison escape drama" },
                { "darkknight", "Batman vs Joker" },
                { "parasite", "Oscar-winning Korean thriller" }
            };

                    // Sports
                    Dictionary<string, string> sportsWords = new Dictionary<string, string>
            {
                { "gym", "Place to exercise" },
                { "ski", "Snow activity with poles" },
                { "run", "Move fast on foot" },
                { "net", "Used in tennis and volleyball" },
                { "bat", "Used in baseball or cricket" },
                { "win", "Opposite of lose" },
                { "golf", "Ball into hole with club" },
                { "swim", "Move through water" },

                { "soccer", "Called football outside US" },
                { "boxing", "Sport with gloves and ring" },
                { "tennis", "Racket and ball sport" },
                { "wrestle", "Fighting sport, WWE" },
                { "archery", "Uses bow and arrow" },
                { "cricket", "Popular in India and UK" },
                { "hockey", "Played on ice or field" },
                { "cycling", "Sport with bicycles" },

                { "basketball", "Shoot ball into hoop" },
                { "snowboarding", "Surfing on snow" },
                { "triathlon", "Swim, bike, run race" },
                { "bodybuilding", "Muscle-building sport" },
                { "mountaineering", "Climbing high peaks" },
                { "equestrian", "Horse riding sport" },
                { "gymnastics", "Flexible artistic sport" },
                { "windsurfing", "Sailing and surfing combo" }
            };

                    // Physics
                    Dictionary<string, string> physicsWords = new Dictionary<string, string>
            {
                { "ion", "Charged atom" },
                { "gas", "State of matter" },
                { "mass", "Amount of matter" },
                { "wave", "Light and sound travel as this" },
                { "atom", "Basic unit of matter" },
                { "volt", "Unit of electric potential" },
                { "lens", "Focuses light" },
                { "push", "Opposite of pull" },

                { "energy", "Capacity to do work" },
                { "moment", "Force × distance" },
                { "vector", "Has magnitude and direction" },
                { "charge", "Positive or negative" },
                { "friction", "Resists motion" },
                { "current", "Flow of electric charge" },
                { "gravity", "Pulls objects to Earth" },
                { "photon", "Particle of light" },

                { "relativity", "Einstein's theory" },
                { "thermodynamics", "Heat and energy laws" },
                { "electromagnetism", "Electricity and magnetism combined" },
                { "quantummechanics", "Physics of the very small" },
                { "superconductivity", "Zero resistance electricity" },
                { "photoelectric", "Light ejects electrons" },
                { "uncertainty", "Heisenberg's principle" },
                { "radioactivity", "Unstable nucleus emits particles" }
            };

                    // Music
                    Dictionary<string, string> musicWords = new Dictionary<string, string>
            {
                { "rap", "Fast rhyming lyrics" },
                { "pop", "Mainstream genre" },
                { "dj", "Plays music at parties" },
                { "duo", "Two-person act" },
                { "song", "Musical composition" },
                { "note", "Basic music symbol" },
                { "band", "Group of musicians" },
                { "beat", "Rhythm unit" },

                { "guitar", "Six-string instrument" },
                { "piano", "Black and white keys" },
                { "chorus", "Repeated song part" },
                { "lyrics", "Words of a song" },
                { "rhythm", "Pattern of beats" },
                { "melody", "Tune you hum" },
                { "singer", "Person who sings" },
                { "concert", "Live music show" },

                { "symphony", "Orchestral music form" },
                { "synthesizer", "Electronic sound machine" },
                { "microphone", "Used to amplify voice" },
                { "improvisation", "Spontaneous performance" },
                { "composition", "Written music piece" },
                { "soundtrack", "Movie background music" },
                { "headphones", "Personal audio gear" },
                { "harmonization", "Blending of voices" }
            };

                    // Countries (correctly categorized)
                    Dictionary<string, string> countryWords = new Dictionary<string, string>
            {
                // Easy (Length <= 4)
                { "usa", "Country in North America" },
                { "iran", "Country in the Middle East" },
                { "iraq", "Country in Western Asia" },
                { "chad", "Central African country" },
                { "peru", "South American country" },
                { "mali", "West African nation" },
                { "laos", "Southeast Asian country" },
                { "cuba", "Island nation in the Caribbean" },

                // Medium (Length > 4 and <= 7)
                { "japan", "Island nation in East Asia" },
                { "spain", "European country known for football" },
                { "canada", "Second largest country by land area" },
                { "france", "Known for its culture, history, and Eiffel Tower" },
                { "germany", "Country known for its engineering" },
                { "brazil", "Largest country in South America" },
                { "mexico", "Country in North America" },
                { "poland", "European country with a rich history" },

                // Hard (Length > 7)
                { "australia", "Country and continent down under" },
                { "argentina", "Country known for its tango dance" },
                { "bangladesh", "Country in South Asia" },
                { "pakistan", "Country in South Asia" },
                { "switzerland", "Known for its neutrality and mountains" },
                { "southkorea", "Country on the Korean Peninsula" },
                { "portugal", "Iberian country famous for its wines" },
                { "malaysia", "Southeast Asian country known for its islands" }
            };

        // History
        Dictionary<string, string> historyWords = new Dictionary<string, string>
            {
                { "war", "Armed conflict" },
                { "king", "Ruler of kingdom" },
                { "rome", "Ancient Italian empire" },
                { "gun", "Used in battles" },
                { "cave", "Stone Age home" },
                { "ship", "Used in ocean voyages" },
                { "flag", "Symbol of a country" },
                { "coin", "Old currency form" },

                { "napoleon", "French military leader" },
                { "hitler", "WWII German dictator" },
                { "revolt", "Against authority" },
                { "empire", "Large group of territories" },
                { "colonial", "Period of colonization" },
                { "battle", "Part of a war" },
                { "treaty", "Signed agreement" },
                { "dynasty", "Ruling family line" },

                { "renaissance", "European rebirth period" },
                { "constitution", "Nation’s legal structure" },
                { "industrialization", "Machine-driven economy" },
                { "revolutionary", "Big change movement" },
                { "civilization", "Advanced human society" },
                { "enlightenment", "18th-century thinking age" },
                { "mesopotamia", "First human civilization" },
                { "philosophers", "Ancient Greek thinkers" }
            };
        private Dictionary<string, string> GetCategoryWords(string category)
        {
            switch (category.ToLower())
            {
                case "movies":
                    return movieWords;
                case "sports":
                    return sportsWords;
                case "physics":
                    return physicsWords;
                case "music":
                    return musicWords;
                case "country":
                    return countryWords;
                case "history":
                    return historyWords;
                default:
                    return countryWords;
            }
        }

        private string GetRandomWord(string difficulty)
        {
            List<string> selectedWords = new List<string>();

            foreach (var entry in selectedCategoryWords)
            {
                int wordLength = entry.Key.Length;

                switch (difficulty.ToLower())
                {
                    case "easy":
                        if (wordLength <= 4)
                            selectedWords.Add(entry.Key);
                        break;
                    case "medium":
                        if (wordLength > 4 && wordLength <= 7)
                            selectedWords.Add(entry.Key);
                        break;
                    case "hard":
                        if (wordLength > 7)
                            selectedWords.Add(entry.Key);
                        break;
                }
            }

            Random rand = new Random();
            int index = rand.Next(selectedWords.Count);
            return selectedWords[index];
        }

        private void LoadThemeImages()
        {
            themes = new Dictionary<Theme, Image[]>
            {
                { Theme.Man, new Image[] {
                    Properties.Resources.man_01, Properties.Resources.man_02,
                    Properties.Resources.man_03, Properties.Resources.man_04,
                    Properties.Resources.man_05, Properties.Resources.man_06,
                    Properties.Resources.man_07, Properties.Resources.man_08,
                    Properties.Resources.man_09, Properties.Resources.man_10
                } },
                { Theme.Flower, new Image[] {
                    Properties.Resources.flower_01, Properties.Resources.flower_02,
                    Properties.Resources.flower_03, Properties.Resources.flower_04,
                    Properties.Resources.flower_05, Properties.Resources.flower_06,
                    Properties.Resources.flower_07, Properties.Resources.flower_08,
                    Properties.Resources.flower_09, Properties.Resources.flower_10
                } },
                { Theme.Castle, new Image[] {
                    Properties.Resources.castle01, Properties.Resources.castle02,
                    Properties.Resources.castle03, Properties.Resources.castle04,
                    Properties.Resources.castle05, Properties.Resources.castle06,
                    Properties.Resources.castle07, Properties.Resources.castle08,
                    Properties.Resources.castle09, Properties.Resources.castle10 }
                },
            };
        }


        private void HangmanGame_Load(object sender, EventArgs e)
        {

            Theme selectedTheme = usedTheme; // already assigned in constructor


            Image[] images = themes[selectedTheme];
            pictureBox1.Image = images[0];

            lblword.Text = "";
            for (int i = 0; i < word.Length; i++)
            {
                lblword.Text += "_ ";
            }
            lbllenght.Text += word.Length.ToString();
            lblPoints.Text = "Points: " + point.ToString();

            label1.Text = "Remaining Time: " + remainingTime.ToString();
            timer = new Timer();
            timer.Interval = 1000;
            timer.Tick += timer_Tick;
            timer.Start();
        }
        private void timer_Tick(object sender, EventArgs e)
        {
            HangmanStart mainPage = new HangmanStart();
            remainingTime--;
            label1.Text = "Remaining Time: " + remainingTime.ToString();
           
            if (remainingTime <= 0)
            {
                timer.Stop();
                this.BackColor = Color.Red;
                MessageBox.Show("Time is over word was: " + word);
            }
        }

        char guess;
        string lastGuess = "";
        List<char> guessedLetters = new List<char>();
        int wrongGuesses = 0;

        private void btnGuess_Click(object sender, EventArgs e)
        {
            string input = txtbxInput.Text.ToLower();

            if (string.IsNullOrWhiteSpace(input) || input.Length != 1 || !char.IsLetter(input[0]))
            {
                MessageBox.Show("Please enter a single letter.");
                txtbxInput.Clear();
                txtbxInput.Focus();
                return;
            }

            guess = input[0];

            if (guessedLetters.Contains(guess))
            {
                MessageBox.Show("You have already guessed this letter.");
                txtbxInput.Clear();
                txtbxInput.Focus();
                return;
            }

            guessedLetters.Add(guess);
            lblguessed.Text += guess + ", ";
            UpdateDisplayedWord();
            wrongGuess();
            lblPoints.Text = "Points: " + point.ToString();
            txtbxInput.Clear();
            txtbxInput.Focus();

            if (!string.IsNullOrEmpty(lblword.Text) && !lblword.Text.Contains("_"))
            {
                MessageBox.Show("Congratulations! You guessed the word!");
                BackColor = Color.Green;
                timer.Stop();
            }
        }
        private void UpdateDisplayedWord()
        {
            char[] display = new char[word.Length];

            for (int i = 0; i < word.Length; i++)
            {
                if (guessedLetters.Contains(word[i]))
                    display[i] = word[i];
                else
                    display[i] = '_';
            }

            lblword.Text = string.Join(" ", display);
        }
        private void btnHint_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(word) && selectedCategoryWords.ContainsKey(word))
            {
                lblHint.Text = selectedCategoryWords[word];
            }
            else
            {
                MessageBox.Show("No hint available.");
            }
        }

        private void wrongGuess()
        {
            if (!word.Contains(guess))
            {
                wrongGuesses++;

                // Tema bir kere parse edilsin
                Theme selectedTheme = usedTheme;
                Image[] images = themes[selectedTheme];

                if (wrongGuesses < images.Length)
                {
                    pictureBox1.Image = images[wrongGuesses];
                }

                point = Math.Max(0, point - 10);
            }

            if (wrongGuesses >= themes[usedTheme].Length - 1)
            {
                MessageBox.Show("Game Over! The word was: " + word);
                BackColor = Color.Red;
                timer.Stop();
            }
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Quitting the game");
            HangmanStart mainPage = new HangmanStart();
            this.Hide();
            mainPage.Show();
        }

    }
}
