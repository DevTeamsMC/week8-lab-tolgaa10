﻿namespace lab7_152120231058_152120221058_Group17
{
    partial class HangmanStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStart = new System.Windows.Forms.Button();
            this.lblStart = new System.Windows.Forms.Label();
            this.btnSettings = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.radioBtnMovies = new System.Windows.Forms.RadioButton();
            this.radioBtnMusic = new System.Windows.Forms.RadioButton();
            this.radioBtnSports = new System.Windows.Forms.RadioButton();
            this.radioBtnCountries = new System.Windows.Forms.RadioButton();
            this.radioBtnPhysics = new System.Windows.Forms.RadioButton();
            this.radioBtnHistory = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.Green;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnStart.Location = new System.Drawing.Point(425, 354);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(283, 94);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblStart
            // 
            this.lblStart.AutoSize = true;
            this.lblStart.BackColor = System.Drawing.SystemColors.Control;
            this.lblStart.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lblStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStart.Location = new System.Drawing.Point(435, 86);
            this.lblStart.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStart.Name = "lblStart";
            this.lblStart.Size = new System.Drawing.Size(263, 54);
            this.lblStart.TabIndex = 2;
            this.lblStart.Text = "HANGMAN";
            this.lblStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSettings
            // 
            this.btnSettings.BackColor = System.Drawing.Color.DarkKhaki;
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSettings.Location = new System.Drawing.Point(425, 486);
            this.btnSettings.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(283, 94);
            this.btnSettings.TabIndex = 3;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = false;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(-7, 1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1128, 704);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // radioBtnMovies
            // 
            this.radioBtnMovies.AutoSize = true;
            this.radioBtnMovies.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnMovies.Location = new System.Drawing.Point(60, 36);
            this.radioBtnMovies.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioBtnMovies.Name = "radioBtnMovies";
            this.radioBtnMovies.Size = new System.Drawing.Size(121, 35);
            this.radioBtnMovies.TabIndex = 4;
            this.radioBtnMovies.TabStop = true;
            this.radioBtnMovies.Text = "Movies";
            this.radioBtnMovies.UseVisualStyleBackColor = true;
            // 
            // radioBtnMusic
            // 
            this.radioBtnMusic.AutoSize = true;
            this.radioBtnMusic.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnMusic.Location = new System.Drawing.Point(60, 105);
            this.radioBtnMusic.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioBtnMusic.Name = "radioBtnMusic";
            this.radioBtnMusic.Size = new System.Drawing.Size(106, 35);
            this.radioBtnMusic.TabIndex = 5;
            this.radioBtnMusic.TabStop = true;
            this.radioBtnMusic.Text = "Music";
            this.radioBtnMusic.UseVisualStyleBackColor = true;
            // 
            // radioBtnSports
            // 
            this.radioBtnSports.AutoSize = true;
            this.radioBtnSports.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnSports.Location = new System.Drawing.Point(259, 36);
            this.radioBtnSports.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioBtnSports.Name = "radioBtnSports";
            this.radioBtnSports.Size = new System.Drawing.Size(114, 35);
            this.radioBtnSports.TabIndex = 6;
            this.radioBtnSports.TabStop = true;
            this.radioBtnSports.Text = "Sports";
            this.radioBtnSports.UseVisualStyleBackColor = true;
            // 
            // radioBtnCountries
            // 
            this.radioBtnCountries.AutoSize = true;
            this.radioBtnCountries.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnCountries.Location = new System.Drawing.Point(259, 105);
            this.radioBtnCountries.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioBtnCountries.Name = "radioBtnCountries";
            this.radioBtnCountries.Size = new System.Drawing.Size(152, 35);
            this.radioBtnCountries.TabIndex = 7;
            this.radioBtnCountries.TabStop = true;
            this.radioBtnCountries.Text = "Countries";
            this.radioBtnCountries.UseVisualStyleBackColor = true;
            // 
            // radioBtnPhysics
            // 
            this.radioBtnPhysics.AutoSize = true;
            this.radioBtnPhysics.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnPhysics.Location = new System.Drawing.Point(463, 36);
            this.radioBtnPhysics.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioBtnPhysics.Name = "radioBtnPhysics";
            this.radioBtnPhysics.Size = new System.Drawing.Size(130, 35);
            this.radioBtnPhysics.TabIndex = 8;
            this.radioBtnPhysics.TabStop = true;
            this.radioBtnPhysics.Text = "Physics";
            this.radioBtnPhysics.UseVisualStyleBackColor = true;
            // 
            // radioBtnHistory
            // 
            this.radioBtnHistory.AutoSize = true;
            this.radioBtnHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.radioBtnHistory.Location = new System.Drawing.Point(463, 105);
            this.radioBtnHistory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioBtnHistory.Name = "radioBtnHistory";
            this.radioBtnHistory.Size = new System.Drawing.Size(121, 35);
            this.radioBtnHistory.TabIndex = 9;
            this.radioBtnHistory.TabStop = true;
            this.radioBtnHistory.Text = "History";
            this.radioBtnHistory.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.radioBtnHistory);
            this.groupBox1.Controls.Add(this.radioBtnSports);
            this.groupBox1.Controls.Add(this.radioBtnMovies);
            this.groupBox1.Controls.Add(this.radioBtnMusic);
            this.groupBox1.Controls.Add(this.radioBtnPhysics);
            this.groupBox1.Controls.Add(this.radioBtnCountries);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(226, 157);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(687, 160);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            // 
            // HangmanStart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1112, 690);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.lblStart);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "HangmanStart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HangmanStart";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.HangmanStart_FormClosed);
            this.Load += new System.EventHandler(this.HangmanStart_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lblStart;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.RadioButton radioBtnMovies;
        private System.Windows.Forms.RadioButton radioBtnMusic;
        private System.Windows.Forms.RadioButton radioBtnSports;
        private System.Windows.Forms.RadioButton radioBtnCountries;
        private System.Windows.Forms.RadioButton radioBtnPhysics;
        private System.Windows.Forms.RadioButton radioBtnHistory;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

