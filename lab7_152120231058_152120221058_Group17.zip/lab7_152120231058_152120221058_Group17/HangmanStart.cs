﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab7_152120231058_152120221058_Group17
{
    public partial class HangmanStart: Form
    {
        public int time;
        public string difficulty;
        public string category;
        public Theme theme;
        private HangmanSettings Settings = new HangmanSettings();
        public HangmanStart()
        {
            InitializeComponent();
        }

        Image[] coverImage;
        private void HangmanStart_Load(object sender, EventArgs e)
        {
            coverImage = new Image[]
            {
                Properties.Resources.cover2
            };

            pictureBox1.Image = coverImage[0];
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            time = Settings.remaningTime > 0 ? Settings.remaningTime : 60;
            difficulty = Settings.difficulty;
            category = GetSelectedRadioButtonText(groupBox1);
            if(category == null)
            {
                MessageBox.Show("Please select a category to play.");
                return;
            }
            theme = Settings.theme;

            HangmanGame game = new HangmanGame(time, difficulty, category, theme);
            this.Hide();
            game.Show();
        }

        private string GetSelectedRadioButtonText(GroupBox groupBox)
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is RadioButton rb && rb.Checked)
                {
                    return rb.Text;
                }
            }
            return null;
        }
        private void HangmanStart_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            Settings.ShowDialog();
        }
    }
}
