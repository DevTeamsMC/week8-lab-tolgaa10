﻿namespace lab7_152120231058_152120221058_Group17
{
    partial class HangmanGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblStart = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnEnd = new System.Windows.Forms.Button();
            this.btnGuess = new System.Windows.Forms.Button();
            this.txtbxInput = new System.Windows.Forms.TextBox();
            this.lblPoints = new System.Windows.Forms.Label();
            this.lblHint = new System.Windows.Forms.Label();
            this.btnHint = new System.Windows.Forms.Button();
            this.lblword = new System.Windows.Forms.Label();
            this.lblguessed = new System.Windows.Forms.Label();
            this.lbllenght = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblDifficulty = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(597, 146);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(453, 438);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblStart
            // 
            this.lblStart.AutoSize = true;
            this.lblStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStart.Location = new System.Drawing.Point(429, 76);
            this.lblStart.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblStart.Name = "lblStart";
            this.lblStart.Size = new System.Drawing.Size(270, 54);
            this.lblStart.TabIndex = 3;
            this.lblStart.Text = "HANGMAN";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.btnEnd);
            this.panel1.Controls.Add(this.btnGuess);
            this.panel1.Controls.Add(this.txtbxInput);
            this.panel1.Controls.Add(this.lblPoints);
            this.panel1.Controls.Add(this.lblHint);
            this.panel1.Controls.Add(this.btnHint);
            this.panel1.Controls.Add(this.lblword);
            this.panel1.Controls.Add(this.lblguessed);
            this.panel1.Controls.Add(this.lbllenght);
            this.panel1.Location = new System.Drawing.Point(65, 146);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(465, 438);
            this.panel1.TabIndex = 4;
            // 
            // btnEnd
            // 
            this.btnEnd.BackColor = System.Drawing.Color.Maroon;
            this.btnEnd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnEnd.Location = new System.Drawing.Point(273, 367);
            this.btnEnd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(143, 36);
            this.btnEnd.TabIndex = 9;
            this.btnEnd.Text = "End Game";
            this.btnEnd.UseVisualStyleBackColor = false;
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // btnGuess
            // 
            this.btnGuess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnGuess.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuess.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGuess.Location = new System.Drawing.Point(148, 367);
            this.btnGuess.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnGuess.Name = "btnGuess";
            this.btnGuess.Size = new System.Drawing.Size(104, 36);
            this.btnGuess.TabIndex = 8;
            this.btnGuess.Text = "Guess";
            this.btnGuess.UseVisualStyleBackColor = false;
            this.btnGuess.Click += new System.EventHandler(this.btnGuess_Click);
            // 
            // txtbxInput
            // 
            this.txtbxInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtbxInput.Location = new System.Drawing.Point(9, 367);
            this.txtbxInput.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtbxInput.Name = "txtbxInput";
            this.txtbxInput.Size = new System.Drawing.Size(116, 34);
            this.txtbxInput.TabIndex = 7;
            // 
            // lblPoints
            // 
            this.lblPoints.AutoSize = true;
            this.lblPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPoints.Location = new System.Drawing.Point(4, 313);
            this.lblPoints.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPoints.Name = "lblPoints";
            this.lblPoints.Size = new System.Drawing.Size(72, 25);
            this.lblPoints.TabIndex = 6;
            this.lblPoints.Text = "Points:";
            // 
            // lblHint
            // 
            this.lblHint.AutoSize = true;
            this.lblHint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHint.Location = new System.Drawing.Point(37, 85);
            this.lblHint.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(0, 20);
            this.lblHint.TabIndex = 5;
            // 
            // btnHint
            // 
            this.btnHint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnHint.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHint.Location = new System.Drawing.Point(335, 85);
            this.btnHint.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHint.Name = "btnHint";
            this.btnHint.Size = new System.Drawing.Size(100, 28);
            this.btnHint.TabIndex = 3;
            this.btnHint.Text = "Hint";
            this.btnHint.UseVisualStyleBackColor = false;
            this.btnHint.Click += new System.EventHandler(this.btnHint_Click);
            // 
            // lblword
            // 
            this.lblword.AutoSize = true;
            this.lblword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblword.Location = new System.Drawing.Point(28, 18);
            this.lblword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblword.Name = "lblword";
            this.lblword.Size = new System.Drawing.Size(249, 31);
            this.lblword.TabIndex = 2;
            this.lblword.Text = "_ _ _ _ _ _ _ _ _ _ _";
            // 
            // lblguessed
            // 
            this.lblguessed.AutoSize = true;
            this.lblguessed.Location = new System.Drawing.Point(5, 249);
            this.lblguessed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblguessed.Name = "lblguessed";
            this.lblguessed.Size = new System.Drawing.Size(152, 16);
            this.lblguessed.TabIndex = 1;
            this.lblguessed.Text = "Already guessed letters:";
            // 
            // lbllenght
            // 
            this.lbllenght.AutoSize = true;
            this.lbllenght.Location = new System.Drawing.Point(5, 212);
            this.lbllenght.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbllenght.Name = "lbllenght";
            this.lbllenght.Size = new System.Drawing.Size(117, 16);
            this.lbllenght.TabIndex = 0;
            this.lbllenght.Text = "Lenght of the word:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(65, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "label1";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCategory.Location = new System.Drawing.Point(65, 75);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(70, 25);
            this.lblCategory.TabIndex = 6;
            this.lblCategory.Text = "label2";
            // 
            // lblDifficulty
            // 
            this.lblDifficulty.AutoSize = true;
            this.lblDifficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDifficulty.Location = new System.Drawing.Point(65, 100);
            this.lblDifficulty.Name = "lblDifficulty";
            this.lblDifficulty.Size = new System.Drawing.Size(70, 25);
            this.lblDifficulty.TabIndex = 7;
            this.lblDifficulty.Text = "label3";
            // 
            // HangmanGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1112, 690);
            this.Controls.Add(this.lblDifficulty);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblStart);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "HangmanGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HangmanGame";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.HangmanGame_FormClosed);
            this.Load += new System.EventHandler(this.HangmanGame_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblStart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblword;
        private System.Windows.Forms.Label lblguessed;
        private System.Windows.Forms.Label lbllenght;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.Button btnHint;
        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.TextBox txtbxInput;
        private System.Windows.Forms.Label lblPoints;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblDifficulty;
    }
}