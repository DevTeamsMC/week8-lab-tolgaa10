﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab7_152120231058_152120221058_Group17
{
    public partial class HangmanSettings: Form
    {
        public int remaningTime;
        public string difficulty;
        public Theme theme;
        public HangmanSettings()
        {
            InitializeComponent();
            cmbBoxTheme.Items.Add("Flower");
            cmbBoxTheme.Items.Add("Man");
            cmbBoxTheme.Items.Add("Castle");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtTime.Text, out int value) && value > 0)
            {
                remaningTime = value;
            }
            else
            {
                MessageBox.Show("Please enter a valid positive number.");
                return;
            }

            if (radiBtnEasy.Checked)
            {
                difficulty = "Easy";
            }
            else if (radioBtnMedium.Checked)
            {
                difficulty = "Medium";
            }
            else if (radioBtnHard.Checked)
            {
                difficulty = "Hard";
            }
            else
            {
                MessageBox.Show("Please select a difficulty level.");
                return;
            }

            if(cmbBoxTheme.SelectedItem != null)
            {
                if(cmbBoxTheme.SelectedItem.ToString() == "Man")
                {
                    theme = Theme.Man;
                }
                else if(cmbBoxTheme.SelectedItem.ToString() == "Flower")
                {
                    theme = Theme.Flower;
                }
                else if (cmbBoxTheme.SelectedItem.ToString() == "Castle")
                {
                    theme = Theme.Castle;
                }
            }
            else
            {
                MessageBox.Show("Please select a theme.");
                return;
            }

            this.Hide();
        }

        private void txtTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            char key = e.KeyChar;

            if(!char.IsDigit(key) && key != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
    }
}
